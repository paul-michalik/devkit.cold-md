#include "BulletPhysicsMinDistCalc.h"
#include "min_dist_calculator.h"

// TODO: add implementation

NSBulletPhysicsExt::BulletPhysicsMinDistCalc::BulletPhysicsMinDistCalc(btCollisionWorld * world_)
   : _world(world_)
{
}

NSBulletPhysicsExt::BulletPhysicsMinDistCalc::~BulletPhysicsMinDistCalc() = default;

std::vector<btPointCollector> NSBulletPhysicsExt::BulletPhysicsMinDistCalc::calculate()
{
   // TODO: implement!
   return std::vector<btPointCollector>();
}

std::vector<btPointCollector> NSBulletPhysicsExt::BulletPhysicsMinDistCalc::calculate(btCollisionObject * obj_a_, btCollisionObject * obj_b)
{
   // TODO: implement!
   return std::vector<btPointCollector>();
}
