#ifndef BULLETPHYSICSMINDISTCALC_H
#define BULLETPHYSICSMINDISTCALC_H

#include <btBulletCollisionCommon.h>
#include <BulletCollision/NarrowPhaseCollision/btPointCollector.h>
#include <vector>

namespace NSBulletPhysicsExt {

class BulletPhysicsMinDistCalc {
   btCollisionWorld* _world;
public:
   BulletPhysicsMinDistCalc(btCollisionWorld* world_);
   ~BulletPhysicsMinDistCalc();

   std::vector<btPointCollector> calculate();

   std::vector<btPointCollector> calculate(
      btCollisionObject* obj_a_,
      btCollisionObject* obj_b_);
};

}
#endif // !BULLETPHYSICSMINDISTCALC_H
